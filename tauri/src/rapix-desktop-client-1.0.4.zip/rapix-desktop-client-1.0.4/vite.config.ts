import { defineConfig } from "vite";

const host = process.env.TAURI_DEV_HOST;
const tauriPlatform = process.env.TAURI_ENV_PLATFORM;
const isTauri = tauriPlatform !== undefined;

console.log("### Tauri information ###");
if (isTauri) {
  console.log(`Platform: ${tauriPlatform}`);
  console.log(`Host: ${host}`);
} else {
  throw new Error("Not a Tauri build.");
}
console.log("");

export default defineConfig((env) => {
  return {
    // prevent vite from obscuring rust errors
    clearScreen: false,

    server: {
      port: 5174,
      // Tauri expects a fixed port, fail if that port is not available
      strictPort: true,
      // if the host Tauri is expecting is set, use it
      host: host || "0.0.0.0",
      hmr: host
        ? {
            protocol: "ws",
            host,
            port: 1421,
          }
        : undefined,

      watch: {
        // tell vite to ignore watching `src-tauri`
        ignored: ["**/src-tauri/**"],
      },
    },

    // Env variables starting with the item of `envPrefix` will be exposed in tauri's source code through
    // `import.meta.env`.
    envPrefix: ["VITE_", "TAURI_ENV_*"],

    build: {
      sourcemap: true,

      // Tauri uses Chromium on Windows and WebKit on macOS and Linux
      target:
        process.env.TAURI_ENV_PLATFORM == "windows"
          ? "chrome105"
          : process.env.TAURI_ENV_PLATFORM == "darwin"
          ? "safari13"
          : undefined,

      // don't minify for debug builds
      minify: !process.env.TAURI_ENV_DEBUG ? "esbuild" : false,
    },

    plugins: [],
  };
});
