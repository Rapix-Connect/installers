#!/bin/bash

# --- Configuration ---
DEFAULT_SIZE=32       # Default icon size in pixels if none specified
DEFAULT_DIR="overlay" # Default output directory
CIRCLE_COLOR="red"
TEXT_COLOR="white"
# Font: Choose a bold sans-serif font available on your system
# Check available fonts with: magick -list font
FONT="DejaVu-Sans-Bold"
# FONT="Arial-Bold" # Alternative common font
# FONT="Liberation-Sans-Bold" # Another alternative

# Pointsize relative to icon size (adjust if text is too big/small for numbers)
POINTSIZE_FACTOR=0.55
# Vertical offset factor (percentage of pointsize to nudge down)
# Adjust this value (e.g., 0.10, 0.12, 0.08) if vertical centering is off
VERTICAL_OFFSET_FACTOR=0.10

# --- Helper Functions ---
usage() {
  echo "Usage: $0 [-s <size>] [-d <directory>] [-h]"
  echo "  -s <size>      : Specify the icon size in pixels (e.g., 16, 24, 32, 48). Default: ${DEFAULT_SIZE}"
  echo "  -d <directory> : Specify the output directory. Default: ${DEFAULT_DIR}"
  echo "  -h             : Show this help message."
  exit 1
}

# Function to check for ImageMagick
check_imagemagick() {
  if command -v magick >/dev/null 2>&1; then
    IM_COMMAND="magick"
  elif command -v convert >/dev/null 2>&1; then
    IM_COMMAND="convert"
  else
    echo "Error: ImageMagick not found." >&2
    echo "Please install ImageMagick (e.g., 'sudo apt install imagemagick' or 'sudo dnf install ImageMagick')." >&2
    exit 1
  fi
  # Check if bc is installed (for floating point math)
  if ! command -v bc >/dev/null 2>&1; then
    echo "Error: 'bc' command not found. Please install it (e.g., 'sudo apt install bc' or 'sudo dnf install bc')." >&2
    exit 1
  fi
  echo "Using ImageMagick command: $IM_COMMAND"
}

# --- Argument Parsing ---
ICON_SIZE="${DEFAULT_SIZE}"
OUTPUT_DIR="${DEFAULT_DIR}"

while getopts "s:d:h" opt; do
  case $opt in
    s) ICON_SIZE="${OPTARG}" ;;
    d) OUTPUT_DIR="${OPTARG}" ;;
    h) usage ;;
    \?) echo "Invalid option: -${OPTARG}" >&2; usage ;;
  esac
done
shift $((OPTIND-1))

# Validate size is a number
if ! [[ "$ICON_SIZE" =~ ^[0-9]+$ ]] || [ "$ICON_SIZE" -le 0 ]; then
  echo "Error: Invalid size specified. Size must be a positive integer." >&2
  usage
fi

# --- Main Logic ---
set -e # Exit immediately if a command exits with a non-zero status.

# Check for dependencies
check_imagemagick

# Create output directory if it doesn't exist
mkdir -p "$OUTPUT_DIR"
if [ ! -d "$OUTPUT_DIR" ]; then
    echo "Error: Could not create output directory '$OUTPUT_DIR'." >&2
    exit 1
fi
echo "Generating icons of size ${ICON_SIZE}x${ICON_SIZE} in directory '$OUTPUT_DIR'..."

# Calculate dimensions based on size
CANVAS_SIZE="${ICON_SIZE}x${ICON_SIZE}"
CENTER=$((ICON_SIZE / 2))
# Leave 1px transparent margin around circle if possible, ensure radius >= 1
RADIUS=$((CENTER > 0 ? CENTER - 1 : 0))
RADIUS=$((RADIUS > 0 ? RADIUS : 1)) # Ensure radius is at least 1 for tiny icons

# Calculate DEFAULT pointsize (using bc for floating point, then converting to integer)
DEFAULT_POINT_SIZE=$(echo "$ICON_SIZE * $POINTSIZE_FACTOR / 1" | bc)
if [ "$DEFAULT_POINT_SIZE" -lt 1 ]; then
    DEFAULT_POINT_SIZE=1 # Ensure minimum pointsize
fi

# Function to generate a single icon WITH TEXT
generate_icon_with_text() {
    local text_content="$1"
    local output_filename="$2"
    local current_point_size
    local current_vertical_offset

    echo "  Generating ${output_filename}..."

    # Use default font size for numbers and other single characters like "!"
    current_point_size="$DEFAULT_POINT_SIZE"
    # Calculate vertical offset based on the default point size
    current_vertical_offset=$(echo "$current_point_size * $VERTICAL_OFFSET_FACTOR / 1" | bc)

    # Create circle and annotate text in one command
    "$IM_COMMAND" -size "$CANVAS_SIZE" xc:transparent \
            -fill "$CIRCLE_COLOR" \
            -draw "circle ${CENTER},${CENTER} $((CENTER + RADIUS)),${CENTER}" \
            -gravity center \
            -font "$FONT" \
            -pointsize "$current_point_size" \
            -fill "$TEXT_COLOR" \
            -annotate "+0+${current_vertical_offset}" "${text_content}" \
            "$output_filename"
}

# --- Generate Numbered Icons (1-9) ---
for i in $(seq 1 9); do
    FILENAME="${OUTPUT_DIR}/icon_${i}.png"
    generate_icon_with_text "$i" "$FILENAME"
done

# --- Generate "9+" Icon ---
FILENAME="${OUTPUT_DIR}/icon_9plus.png"
generate_icon_with_text "9+" "$FILENAME"

# --- Generate Alert (!) Icon ---
FILENAME="${OUTPUT_DIR}/icon_alert.png" # Changed filename
generate_icon_with_text "!" "$FILENAME"   # Call the function with "!"


# --- Cleanup ---
# No temporary files needed

echo "----------------------------------------"
echo "Icon generation complete!"
echo "Icons saved in: $OUTPUT_DIR"
echo "----------------------------------------"

exit 0