/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "index.html",
  ],
  theme: {
    extend: {
      screens: {
        // Allow doing things like `screen:link` to apply styles for non-print.
        screen: { raw: 'screen' },
      },
    },
  },
  /** @type {import('daisyui').Config} */
  daisyui: {
    themes: [
      {
        winter: {
          ...require("daisyui/src/theming/themes")["winter"],
          success: "#34A853"
        },
        night: {
          ...require("daisyui/src/theming/themes")["night"],
        }
      },
    ],
    darkTheme: "night",
  },
  darkMode: ['selector', '[data-theme="night"]'],
  plugins: [
    require('@tailwindcss/typography'),
    require("daisyui"),
  ],
}