$env:TAURI_SIGNING_PRIVATE_KEY=$(Get-Content "../keys/tauriClient.key")
